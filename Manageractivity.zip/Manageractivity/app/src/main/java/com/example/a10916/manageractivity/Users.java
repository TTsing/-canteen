//package com.example.a10916.manageractivity;
//
//import org.litepal.crud.DataSupport;
//
///**
// * Created by 10916 on 2020/11/15.
// */
//
//public class Users extends DataSupport{
//    private int id;
//    private String idcard;
//    private String name;
//    private String zhuanye;
//    private String banji;
//    public void setId(int id) {
//        this.id = id;
//    }
//    public void setIdcard(String idcard) {
//        this.idcard = idcard;
//    }
//    public void setName(String name) {
//        this.name = name;
//    }
//    public int getId(){
//        return id;
//    }
//    public String getIdcard(){
//        return idcard;
//    }
//    public String getName(){
//        return  name;
//    }
//    public String getZhuanye() {
//        return zhuanye;
//    }
//    public String getBanji() {
//        return banji;
//    }
//    public void setBanji(String banji) {
//        this.banji = banji;
//    }
//    public void setZhuanye(String zhuanye) {
//        this.zhuanye = zhuanye;
//    }
//}
